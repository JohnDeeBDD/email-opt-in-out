<?php

die("error");