<?php

die("error");
